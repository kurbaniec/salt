package pass.dev.server

import pass.dev.db.User
import pass.dev.db.UserRepo
import pass.dev.test.db.TestRepo
import pass.dev.test.db.UserTesto
import pass.dev.test.db.UserTestoRepo
import pass.salt.annotations.*
import pass.salt.annotations.Controller
import pass.salt.modules.server.HTTPTransport
import pass.salt.modules.server.security.SessionUser
import pass.salt.modules.server.webparse.Model

@Controller
class Controller {
    @Autowired
    lateinit var userRepo: UserRepo

    @Get("/")
    fun test(): String {
        //testDB()
        return "hello"
    }

    @Post("/testpost")
    fun testPost(): HTTPTransport {
        /**return HTTPTransport(HTTPTransport.Header("HTTP/1.1 200 OK",
                "Content-Type: application/x-www-form-urlencoded",
                "Content-Length: 9"),
                HTTPTransport.Body("name=baum"))*/
        return HTTPTransport(HTTPTransport.Body("name=baum")).ok()
    }

    @Get("/login")
    fun login(m: Model): String {
        return "login"
    }

    @Get("/index")
    fun passwdIndex(m: Model, s: SessionUser): String {
        return "index"
    }

    @Post("/register")
    fun registerUser(@Param("username") username: String, @Param("password") password: String): HTTPTransport {
        val test = userRepo.findByUsernameAndPassword(username, password)
        return if (test == null) {
            var setPassword = false
            do {
                val nameSpace = ('0'..'9').toList().toTypedArray()
                val myid = (1..101).map { nameSpace.random() }.joinToString("")
                if (userRepo.findByMyid(myid) == null) {
                    userRepo.insert(User(myid, username, password))
                    setPassword = true
                }
            } while (!setPassword)
            HTTPTransport().ok()
        }
        else HTTPTransport().forbidden()
    }






    /**
    fun testDB() {
        val a = userTestoRepo.findAll()
        userTestoRepo.insert(UserTesto("1", "baum", "3"))
        val b = userTestoRepo.findByUsername("baum")
        userTestoRepo.updateAll("username", "baum", Pair("username", "dada"))
        val d = userTestoRepo.findAll()
        userTestoRepo.deleteAll("username", "dada")
        val e = userTestoRepo.findAll()
        val c = userTestoRepo.countAll()
        val a2 = testRepo.findAll()
        val b2 = testRepo.findByTest("tt")
        val c2 = testRepo.countAll()
    }*/
}