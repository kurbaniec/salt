package pass.dev.server

import pass.dev.db.User
import pass.dev.db.UserRepo
import pass.dev.test.db.TestRepo
import pass.dev.test.db.UserTesto
import pass.dev.test.db.UserTestoRepo
import pass.salt.annotations.Autowired
import pass.salt.annotations.Controller
import pass.salt.annotations.Get
import pass.salt.annotations.Post
import pass.salt.modules.server.HTTPTransport
import pass.salt.modules.server.security.SessionUser
import pass.salt.modules.server.webparse.Model

@Controller
class Controller {
    @Autowired
    lateinit var userRepo: UserRepo

    @Get("/")
    fun test(): String {
        //testDB()
        return "hello"
    }

    @Post("/testpost")
    fun testPost(): HTTPTransport {
        /**return HTTPTransport(HTTPTransport.Header("HTTP/1.1 200 OK",
                "Content-Type: application/x-www-form-urlencoded",
                "Content-Length: 9"),
                HTTPTransport.Body("name=baum"))*/
        return HTTPTransport(HTTPTransport.Header(), HTTPTransport.Body("name=baum")).ok()
    }

    @Get("/login")
    fun login(m: Model): String {
        return "login"
    }

    @Get("/index")
    fun passwdIndex(m: Model, s: SessionUser): String {
        return "index"
    }


    /**
    fun testDB() {
        val a = userTestoRepo.findAll()
        userTestoRepo.insert(UserTesto("1", "baum", "3"))
        val b = userTestoRepo.findByUsername("baum")
        userTestoRepo.updateAll("username", "baum", Pair("username", "dada"))
        val d = userTestoRepo.findAll()
        userTestoRepo.deleteAll("username", "dada")
        val e = userTestoRepo.findAll()
        val c = userTestoRepo.countAll()
        val a2 = testRepo.findAll()
        val b2 = testRepo.findByTest("tt")
        val c2 = testRepo.countAll()
    }*/
}