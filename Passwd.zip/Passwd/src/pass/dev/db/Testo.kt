package pass.dev.db

class Testo {
    lateinit var test: String
}