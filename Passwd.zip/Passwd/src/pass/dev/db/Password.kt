package pass.dev.db

class Password() {
    lateinit var userid: String
    lateinit var name: String
    lateinit var password: String
    lateinit var tag: String

    constructor(userid: String, name: String, password: String, tag: String): this() {
        this.userid = userid
        this.name = name
        this.password = password
        this.tag = tag
    }
}