package pass.dev.db

class User {
    lateinit var id: String
    lateinit var username: String
    lateinit var password: String
}