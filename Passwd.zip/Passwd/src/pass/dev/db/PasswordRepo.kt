package pass.dev.db

import pass.salt.annotations.MongoDB
import pass.salt.modules.db.mongo.MongoRepo

@MongoDB
interface PasswordRepo: MongoRepo<Password, String> {

    fun findByUserid(userid: String): List<Password>?

    fun findByUseridAndName(userid: String, name: String): List<Password>?

}