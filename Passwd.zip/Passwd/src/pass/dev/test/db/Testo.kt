package pass.dev.test.db

class Testo {
    lateinit var test: String
}