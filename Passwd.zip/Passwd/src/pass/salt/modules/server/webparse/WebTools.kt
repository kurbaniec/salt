package pass.salt.modules.server.webparse

class WebTools {
    companion object {

        fun buildLogin(preUrl: String, login: String, success: String): String {
            var lg = script + "\"" + preUrl + login + "\""
            lg += script2 + "console.log(\"Wrong credentials\");"
            lg += script3 + "window.location.href = \"" + preUrl + success + "\"" + script4
            return lg
        }

        fun buildLogout(preUrl: String, logout: String, login: String): String {
            var lgo = lo + "\"" + preUrl + logout + "\""
            lgo += lo2 +  "window.location.href = \"" + preUrl + login + "\"" + lo3
            return lgo
        }


        val script =
                """
            <script>
            ${'$'}('#submitButton').on('click', function() {auth() });
            ${'$'}('#username').keypress(function (e) {
                if (e.which == 13) {
                    auth()
                }
            });
            ${'$'}('#password').keypress(function (e) {
                if (e.which == 13) {
                    auth()
                }
            });
            function auth() {
                ${'$'}.ajax({
                    url: 
        """
        val script2 =
                """
                    ,
                    type: 'POST',
                    headers: {
                    "Authorization": "Basic " + btoa(${'$'}('#username').val() + ":" + ${'$'}('#password').val())
                    },
                    async: true,
                    statusCode: {
                        403: function(xhr) {
                            $("#alert").text("Wrong credentials");
                            $("#alert").removeAttr("hidden");
        """
        val script3 =
                """
                        }
                    },
                    success: function() {
        """
        val script4 =
                """
                    }
                })
            }
            </script>
        """

        val lo =
                """
            <script>
            ${'$'}('#logoutButton').on('click', function() {logout() });
            function logout() {
                ${'$'}.ajax({
                    url: 
        """
        val lo2 =
                """
                    ,
                    type: 'POST',
                    async: true,
                    success: function() {
        """
        val lo3 =
                """
                    }
                })
            }
            </script>
        """
    }
}