package pass.salt.modules.server.mapping

enum class HTTPMethod {
    GET,
    POST
}