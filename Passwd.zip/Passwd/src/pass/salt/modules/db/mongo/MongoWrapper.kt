package pass.salt.modules.db.mongo

import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import org.bson.Document
import pass.dev.db.User
import pass.dev.db.UserRepo
import java.lang.Exception
import java.lang.reflect.*
import kotlin.reflect.full.memberProperties
import java.lang.reflect.ParameterizedType




class MongoWrapper: InvocationHandler {
    lateinit var clazz: Class<*>
    lateinit var db: MongoDatabase
    lateinit var collName: String

    companion object {
        fun  <W>getWrapper(cls: Class<W>, db: MongoDatabase, collName: String): W {
            val wrappy = MongoWrapper()
            wrappy.clazz = cls
            wrappy.db = db
            wrappy.collName = collName
            return Proxy.newProxyInstance(cls.classLoader, arrayOf(cls), wrappy) as W
        }
    }

    override fun invoke(proxy: Any?, method: Method?, args: Array<out Any>?): Any? {
        var types: Array<Type>? = null
        val ifaces = clazz.genericInterfaces
        if (ifaces != null) {
            for (ifc in ifaces) {
                if (ifc is ParameterizedType && ifc.rawType.typeName.endsWith("MongoRepo")) {
                    types = ifc.actualTypeArguments
                    break
                }
            }
        }
        if (types != null) {
            if (method != null) {
                // Query
                if (method.name.startsWith("find") && (args == null || args.isEmpty())) {
                    return "Baum";
                // Insert
                } else if (method.name.startsWith("insert")) {
                    if (method.name == "insert" && args != null && args.size == 1) {
                        val baum = db.getCollection<Any>(collName, types.first().javaClass)
                        //val baum = db.getCollection<Any>(collName, Any::class.java)
                        val a = baum.countDocuments()
                        try {
                            val user = User("1", "2", "3")
                            baum.insertOne(user)
                        }
                        catch (ex: Exception) {
                            println("kek")
                        }
                        val b = baum.countDocuments()
                        println("kek")
                    }
                }
            }
            return null
        }
        else {
            // TODO exception
            return null
        }
    }
}