package pass.salt.modules.db.mongo

import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.mongodb.client.model.Filters.eq
import pass.dev.db.User
import pass.salt.exceptions.ExceptionsTools
import java.lang.Exception
import java.lang.reflect.*
import java.lang.reflect.ParameterizedType
import java.util.logging.Logger
import kotlin.reflect.KClass
import kotlin.reflect.full.isSubclassOf

class MongoWrapper: InvocationHandler {
    lateinit var clazz: Class<*>
    lateinit var db: MongoDatabase
    lateinit var collName: String
    lateinit var collection: MongoCollection<Any>
    lateinit var types: Pair<Class<*>, Class<*>>
    lateinit var type: String
    val log = Logger.getGlobal()

    companion object {
        fun  <W>getWrapper(cls: Class<W>, db: MongoDatabase, collName: String): W {
            val wrappy = MongoWrapper()
            wrappy.clazz = cls
            wrappy.db = db
            wrappy.collName = collName
            init(wrappy) // TODO what if wrappy init fails?
            return Proxy.newProxyInstance(cls.classLoader, arrayOf(cls), wrappy) as W
        }

        fun init(wrappy: MongoWrapper): Boolean {
            var types: Array<Type>? = null
            val ifaces = wrappy.clazz.genericInterfaces
            if (ifaces != null) {
                for (ifc in ifaces) {
                    if (ifc is ParameterizedType && ifc.rawType.typeName.endsWith("MongoRepo")) {
                        types = ifc.actualTypeArguments
                        wrappy.types = Pair(types.first() as Class<*>, types.last() as Class<*>)
                        val tmp = (types.first() as Class<*>).simpleName
                        wrappy.type = tmp.first().toLowerCase() + tmp.substring(1)
                        break
                    }
                }
            }
            return if (types != null) {
                wrappy.collection = wrappy.db.getCollection<Any>(wrappy.collName, types.first() as Class<Any>)
                true
            } else false
        }
    }

    override fun invoke(proxy: Any?, method: Method?, args: Array<out Any>?): Any? {
        if (method != null) {
            // Query
            if (method.name.startsWith("find") ) {
                if (method.name == "findAll" && (args == null || args.isEmpty())) {
                    try {
                        val a = collection.find()
                        val list = mutableListOf<Any>()
                        a.forEach {
                            list.add(it)
                        }
                        return if (list.isEmpty()) {
                            null
                        } else list
                    }
                    catch (ex: Exception) {
                        println("kek")
                    }

                }
                else if (args != null && args.size == 1 && args.first() is String) {
                    //val tt = db.getCollection(collName)
                    //val tt2 = tt.find()
                    //val tt3 = tt2.toList()
                    val attribute = method.name.substring(6,7).toLowerCase() + method.name.substring(7)
                    val a = collection.find(eq(attribute, args.first()))
                    val list = mutableListOf<Any>()
                    a.forEach {
                        list.add(it)
                    }
                    return if (list.isEmpty()) {
                        null
                    } else list
                }
                return null
            // Insert
            } else if (method.name.startsWith("insert")) {
                if (method.name == "insert" && args != null && args.size == 1) {
                    //if (args.first()::class.java is types.first::class.java) {
                    /**val a = args.first()::class
                    val b = types.first.kotlin
                    val c = a == b*/

                    if (args.first()::class == types.first.kotlin) {
                        try {
                            collection.insertOne(args.first())
                        }
                        catch (ex: Exception) {
                            log.warning("Cannot add object ${args.first()} to database. Reason:")
                            log.warning(ExceptionsTools.exceptionToString(ex))
                            log.warning("Did you initalize all properties of the object?")
                        }
                    }
                    //val baum = db.getCollection<Any>(collName, types.first().javaClass)
                    //val baum = db.getCollection<Any>(collName, Any::class.java)
                    /**val a = collection.countDocuments()
                    try {
                        val user = User("1", "2", "3")
                        collection.insertOne(user)
                    }
                    catch (ex: Exception) {
                        println("kek")
                    }
                    val b = collection.countDocuments()
                    println("kek")*/
                }
            } else if (method.name.startsWith("count")) {
                if (method.name == "countAll" && (args == null || args.isEmpty())) {
                    return collection.countDocuments()
                }
            }
        }
        return null
    }
}