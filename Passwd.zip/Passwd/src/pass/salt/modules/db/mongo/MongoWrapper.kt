package pass.salt.modules.db.mongo

import pass.dev.db.UserRepo
import java.lang.reflect.*
import kotlin.reflect.full.memberProperties
import java.lang.reflect.ParameterizedType




class MongoWrapper: InvocationHandler {
    lateinit var clazz: Class<*>

    companion object {
        fun  <W>getWrapper(cls: Class<W>): W {
            val wrappy = MongoWrapper()
            wrappy.clazz = cls
            return Proxy.newProxyInstance(cls.classLoader, arrayOf(cls), wrappy) as W
        }
    }

    override fun invoke(proxy: Any?, method: Method?, args: Array<out Any>?): Any? {
        //val properties = clazz.kotlin.memberProperties
        //val interfaces = clazz.interfaces
        //val da = interfaces.first()
        val tt = clazz.genericInterfaces
        val da2 = UserRepo::class.java
        if (da2 is ParameterizedType) {
            val b = da2.actualTypeArguments
        }
        val tt2 = da2.genericInterfaces
        for (t in tt) {
            if (t is ParameterizedType) {
                val b = t
                val c = b.actualTypeArguments
                println("bau")
            }
        }
        /**val interfaces = clazz.interfaces
        val tt = interfaces.first().javaClass
        val test = tt.genericInterfaces
        val baum = tt.genericSuperclass
        for (ge in test) {
            if (ge is ParameterizedType) {
                val geTypes = ge.actualTypeArguments
                for (type in geTypes) {
                    println(type)
                }
            }
        }
        for (ge in test) {
            if (ge is GenericArrayType) {
                val b = ge.genericComponentType
            }
        }*/
        /**
        val test = interfaces.first().javaClass.genericSuperclass
        val t2 = (test as ParameterizedType).actualTypeArguments[0]*/
        if (method != null) {
            if (method.name.startsWith("find") && (args == null || args.isEmpty())) {
                return "Baum";
            }
            else if (method.name.startsWith("insert")) {
                if (method.name == "insert" && args != null && args.size == 1) {

                }
            }
        }
        return null
    }
}