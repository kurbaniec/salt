package pass.salt.modules.db.mongo

interface MongoRepo<T, I> {

    fun findAll(): ArrayList<T>?

    fun insert(data: T)

    fun countAll(): Long

    fun updateAll(field: String, match: Any, vararg update: Pair<String, Any>)

    fun deleteAll(field: String, match: Any)

}