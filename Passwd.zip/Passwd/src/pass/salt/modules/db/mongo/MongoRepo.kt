package pass.salt.modules.db.mongo

interface MongoRepo<T, I> {

    fun findAll(): ArrayList<T>?

    fun insert(data: T)

    fun countAll(): Long
}